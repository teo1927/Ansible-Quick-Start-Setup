#!/bin/bash
BASEDIR=$(dirname $0)
ABSPATH=$(readlink -f $0)
ABSDIR=$(dirname $ABSPATH)
NAME="$1"
if [ -z "$1" ] ; then
  echo "No Role Name Defined" ;
  echo "Try Running: New-Role.sh <Role-Name>" ;
  exit ;
  fi
cd $BASEDIR
ansible-galaxy init $NAME