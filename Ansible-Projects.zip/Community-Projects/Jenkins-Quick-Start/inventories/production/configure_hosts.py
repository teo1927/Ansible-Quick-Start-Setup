print('+------------------------------------------------------+')
print('|               Ansible QuickStart Script              |')
print('+------------------------------------------------------+')
print()
print('1. Mass Deployment - One Time Configuration Excluding Hostname and IPs')
print('2. Box By Box Deployment - Full Configuration For Each Node')
print()
print('Configuration Settings: IP - Name - Connection Type - Username - Password Or Certificate')
print()
print('#WARNING: Host File Must Be In The Same Working Directory As This Script#')
print()
while True:
  route = input('Configuration Method (1 or 2): ')
  if route == '1':
    name = input('Host Name: ')
    ip = input('Host IP: ')
    print('1. SSH')
    print('2. WINRM')
    while True:
      connection = input('Connection Type (1 or 2):')
      if connection == '1':
        connection = 'ssh'
        break
      elif connection == '2':
        connection = 'winrm'
        break
      else:
        print('Invalid Option Please Enter 1 or 2')
    username = input('Username: ')
    if connection == 'ssh':
      while True:
        print('1. Password')
        print('2. Private Key')
        passwordmethod = input('Authentication Method (1 or 2): ')
        if passwordmethod == '1':
          password = input('Password: ')
          break
        elif passwordmethod == '2':
          pathtopem = input('Path To Private Key (.pub/.pem): ')
          break
        else:
          print('Invalid Option Please Enter 1 or 2')
    elif connection == 'winrm':
      password = input('Password: ')
    

    if connection == 'ssh' and passwordmethod == '1':
      hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_ssh_pass={}'.format(name,ip,connection,username,password))
    elif connection == 'ssh' and passwordmethod == '2':
      hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_ssh_private_key_file={}'.format(name,ip,connection,username,pathtopem))    
    elif connection == 'winrm':
      hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_password={}'.format(name,ip,connection,username,password))    
    hostsfile = open('hosts', 'a')
    hostsfile.write(hostsconfig)
    hostsfile.write('\n')
    hostsfile.close()
    print('Host Added')
    while True:
      more = input('Add Another? (y or n)')
      if more in ['y', 'Y', 'yes', 'Yes']:
        while True:
          name = input('Host Name: ')
          ip = input('Host IP: ')
          if connection == 'ssh' and passwordmethod == '1':
            hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_ssh_pass={}'.format(name,ip,connection,username,password))
          elif connection == 'ssh' and passwordmethod == '2':
            hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_ssh_private_key_file={}'.format(name,ip,connection,username,pathtopem)) 
          elif connection == 'winrm':
            hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_password={}'.format(name,ip,connection,username,password))
          hostsfile = open('hosts', 'a')
          hostsfile.write(hostsconfig)
          hostsfile.write('\n')
          hostsfile.close()
          print('Host Added')
          while True:
            more = input('Add Another? (y or n)')
            if more in ['y', 'Y', 'yes', 'Yes']:
              break
            elif more in ['n','N','no','No']:
              exit()
            else:
              print('Invalid Option Please Enter y or n')
      elif more in ['n','N','no','No']:
        exit()
      else:
        print('Invalid Option Please Enter y or n')
    
  if route == '2':
    while True:
      name = input('Host Name: ')
      ip = input('Host IP: ')
      print('1. SSH')
      print('2. WINRM')
      while True:
        connection = input('Connection Type (1 or 2): ')
        if connection == '1':
          connection = 'ssh'
          break
        elif connection == '2':
          connection = 'winrm'
          break
        else:
          print('Invalid Option Please Enter 1 or 2')
      username = input('Username: ')
      if connection == 'ssh':
        print('1. Password')
        print('2. Private Key')
        while True:
          passwordmethod = input('Authentication Method (1 or 2): ')
          if passwordmethod == '1':
            password = input('Password: ')
            break
          elif passwordmethod == '2':
            pathtopem = input('Path To Private Key (.pub/.pem): ')
            break
          else:
            print('Invalid Option Please Enter 1 or 2')
      elif connection == 'winrm':
        password = input('Password: ')
      
      if connection == 'ssh' and passwordmethod == '1':
        hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_ssh_pass={}'.format(name,ip,connection,username,password))
      elif connection == 'ssh' and passwordmethod == '2':
        hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_ssh_private_key_file={}'.format(name,ip,connection,username,pathtopem))
      elif connection == 'winrm':
        hostsconfig = ('{} ansible_host={} ansible_connection={} ansible_user={} ansible_password={}'.format(name,ip,connection,username,password))
      hostsfile = open('hosts', 'a')
      hostsfile.write(hostsconfig)
      hostsfile.write('\n')
      hostsfile.close()
      print('Host Added')
      while True:
        more = input('Add Another? (y or n)')
        if more in ['y', 'Y', 'yes', 'Yes']:
          break
        elif more in ['n','N','no','No']:
          exit()
        else:
          print('Invalid Option Please Enter y or n')
  else:
    print('Invalid Option Please Enter 1 or 2')