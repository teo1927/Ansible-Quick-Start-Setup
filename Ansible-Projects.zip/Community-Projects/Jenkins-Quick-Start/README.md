# Ansible Playbook for deploying Jenkins via Docker on EC2

This is a work in progress playbook for running Jenkins via Docker on EC2 to support development of a Jenkins Golden AMI pipeline. 

## Usage

### Pre-requisites

- [Ansible installed](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html) (either in Windows Subsystem for Linux (WSL) or a VM if on Windows, or your Mac)
- SSH key for the EC2 instance you are running it against (either a new one you made, or one received from a colleague) [added to your trust store](https://docs.github.com/en/github/authenticating-to-github/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent#adding-your-ssh-key-to-the-ssh-agent).

`ansible-playbook jenkins.yml -vv` 

- In some environments (like WSL in a Windows path or shared folder on a VM), you may need to set the `ANSIBLE_CONFIG=<path to ansible.cfg>` environment variable to bypass the "Ansible is being run in a world writable directory" warning. You should respect it in a prod environment, though.
- It may also be helpful to set `ANSIBLE_STDOUT_CALLBACK=yaml` for better output readability.
- `-vv` sets verbose level 2, which allows you to see the output (e.g. for Jenkins default password)
- Change the `ansible_host` variable in `inventories/dev/hosts` to point to the target host.
## Roles

### Docker 

This role simply installs Docker CE and Docker Compose according to:
- https://docs.docker.com/engine/install/centos/
- https://docs.docker.com/compose/install/

### Jenkins

This role installs pre-requisites for Ansible's Docker modules and deploys Jenkins. Ansible has modules for managing Jenkins plugins, so it should be possible to increase the amount of setup automated. 
